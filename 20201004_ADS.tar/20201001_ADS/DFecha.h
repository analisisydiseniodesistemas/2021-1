/**DFecha.h - Ejemplo de un archivo de cabecera.
En este caso, se est\'a declarando una estructura.
*/
// GRUPO 1TM1
struct Fecha {// Esto forma parte del primer programa del curso
  unsigned int d,m,a;  /*dia,mes,an\~{n}o*/
};/*end struct Fecha*/
string get_string_fecha(struct Fecha F);

